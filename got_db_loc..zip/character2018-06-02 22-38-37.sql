Select ch_id, ch_frist, ch_last, ch_numep, ch_epstart, ch_epend, ch_alias, ch_gender, ch_a_id from got_db_loc.`character`
USE got_db_loc;

CREATE TABLE `character` (
  `ch_id` varchar(45) NOT NULL,
  `ch_frist` text,
  `ch_last` text,
  `ch_numep` int(11) DEFAULT NULL,
  `ch_epstart` int(11) DEFAULT NULL,
  `ch_epend` int(11) DEFAULT NULL,
  `ch_alias` text,
  `ch_gender` text,
  `ch_a_id` varchar(45) NOT NULL,
  PRIMARY KEY (`ch_id`),
  UNIQUE KEY `ch_id_UNIQUE` (`ch_id`),
  KEY `fk_character_actor1_idx` (`ch_a_id`),
  CONSTRAINT `fk_character_actor1` FOREIGN KEY (`ch_a_id`) REFERENCES `actor` (`a_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc001','Tyrion','Lannister',61,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc002','Cersei','Lannister',58,2011,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc003','Daenerys','Targaryen',56,2011,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc004','Jon','Snow',56,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc005','Sansa','Stark',54,2011,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc006','Arya','Stark',53,2011,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc007','Jaime','Lannister',49,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc008','Jorah','Mormont',48,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc009','Theon','Greyjoy',43,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc010','Samwell','Tarly',43,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc011','Petyr','Baelish',41,2011,2017,'Littlefinger','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc012','Lord','Varys',41,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc013','Brienne of Tarth','',37,2012,2017,'Brienne of Tarth','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc014','Davos','Seaworth',36,2012,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc015','Bran','Stark',35,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc016','Bronn','',34,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc017','Missandei','',34,2013,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc018','Sandor','Clegane',33,2011,2017,'The Hound','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc019','Grand Maester Pycelle','',31,2011,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc020','Eddison','Tollett',30,2012,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc021','Podrick','Payne',30,2012,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc022','Melisandre','',28,2012,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc023','Tormund','Giantsbane',28,2013,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc024','Grey','Worm',28,2013,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc025','Tywin','Lannister',27,2011,2015,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc026','Margaery','Tyrell',26,2012,2016,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc027','Joffrey','Baratheon',26,2011,2014,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc028','Catelyn','Stark',25,2011,2013,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc029','Barristan','Selmy',25,2011,2015,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc030','Stannis','Baratheon',24,2012,2015,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc031','Gilly','',24,2012,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc032','Hodor','',23,2011,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc033','Grenn','',22,2011,2014,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc034','Robb','Stark',21,2011,2013,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc035','Loras','Tyrell',21,2011,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc036','Shae','',20,2011,2014,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc037','Ramsay','Bolton',20,2013,2016,'Ramsay Snow','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc038','Roose','Bolton',19,2012,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc039','Alliser','Thorne',19,2011,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc040','Gendry','',19,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc041','Qyburn','',19,2013,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc042','Daario','Naharis',18,2014,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc043','Olenna','Tyrell',18,2013,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc044','Tommen','Baratheon',18,2013,2016,'Martyn Lannister','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc045','Ygritte','',17,2012,2014,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc046','Jaqen','H''ghar',17,2012,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc047','Olly','',17,2014,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc048','Meryn','Trant',17,2011,2015,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc049','Osha','',16,2011,2016,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc050','Meera','Reed',16,2013,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc051','Lancel','Lannister',16,2011,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc052','Janos','Slynt',15,2011,2015,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc053','Maester','Luwin',14,2011,2012,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc054','Yara','Greyjoy',14,2012,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc055','Gregor','Clegane',14,2014,2017,'The Mountain','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc056','Ros','',14,2011,2013,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc057','Rickon','Stark',14,2011,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc058','Othell','Yarwyck',14,2011,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc059','Ellaria','Sand',13,2014,2017,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc060','Rodrik','Cassel',13,2011,2012,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc061','Mace','Tyrell',13,2014,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc062','Pypar','',13,2011,2014,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc063','Irri','',13,2011,2012,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc064','High','Sparrow',12,2015,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc065','Jeor','Mormont',12,2011,2013,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc066','Kevan','Lannister',12,2011,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc067','Rast','',12,2011,2014,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc068','Hot','Pie',12,2011,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc069','Talisa','Stark',11,2012,2013,'Talisa Maegyr','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc070','Maester','Aemon',11,2011,2015,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc071','The','Waif',11,2015,2016,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc072','Doreah','',11,2011,2012,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc073','Eddard','Stark',11,2011,2013,'Ned','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc074','Thoros of Myr','',10,2013,2017,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc075','Selyse','Baratheon',10,2013,2015,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc076','Jojen','Reed',10,2013,2014,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc077','Shireen','Baratheon',10,2013,2015,'','female','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc078','Bowen','Marsh',10,2015,2016,'','male','');
insert into `character`(`ch_id`,`ch_frist`,`ch_last`,`ch_numep`,`ch_epstart`,`ch_epend`,`ch_alias`,`ch_gender`,`ch_a_id`) values ('chrc079','Khal','Drogo',10,2011,2012,'','male','');
