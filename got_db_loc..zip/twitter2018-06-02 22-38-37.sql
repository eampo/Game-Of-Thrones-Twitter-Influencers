Select twitter_id, twitter_name from got_db_loc.twitter
USE got_db_loc;

CREATE TABLE `twitter` (
  `twitter_id` varchar(45) NOT NULL,
  `twitter_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`twitter_id`),
  UNIQUE KEY `twitter_id_UNIQUE` (`twitter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw001','emiliaclarke');
insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw002','peter_dinklage');
insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw003','lovegwendoline');
insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw004','jackgleeson');
insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw005','iwanrheon');
insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw006','IAMLenaHeadey');
insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw007','nikolajcw');
insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw008','Maisie_Williams');
insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw009','SophieT');
insert into `twitter`(`twitter_id`,`twitter_name`) values ('tw010','_richardmadden');
