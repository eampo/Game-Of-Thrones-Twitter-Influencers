Select a_id, actor_first, actor_last, fka_twitter_id from got_db_loc.actor
USE got_db_loc;

CREATE TABLE `actor` (
  `a_id` varchar(45) NOT NULL,
  `actor_first` text,
  `actor_last` text,
  `fka_twitter_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`a_id`),
  KEY `twitter_id_idx` (`fka_twitter_id`),
  CONSTRAINT `twitter_id` FOREIGN KEY (`fka_twitter_id`) REFERENCES `twitter` (`twitter_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a001','Peter','Dinklage','tw002');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a002','Lena','Headey','tw006');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a003','Emilia','Clarke','tw001');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a004','Kit','Harington',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a005','Sophie','Turner','tw009');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a006','Maisie','Williams','tw008');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a007','Nikolaj','Coster-Waldau','tw007');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a008','Iain','Glen',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a009','Alfie','Allen',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a010','John','Bradley',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a011','Aidan','Gillen',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a012','Conleth','Hill',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a013','Gwendoline','Christie','tw003');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a014','Liam','Cunningham',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a015','Isaac','Wright',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a016','Jerome','Flynn',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a017','Nathalie','Emmanuel',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a018','Rory','McCann',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a019','Julian','Glover',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a020','Ben','Crompton',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a021','Daniel','Portman',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a022','Carice ','van Houten',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a023','Kristofer','Hivju',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a024','Jacob','Anderson',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a025','Charles','Dance',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a026','Natalie','Dormer',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a027','Jack','Gleeson','tw004');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a028','Michelle','Fairley',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a029','Ian','McElhinney',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a030','Stephen','Dillane',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a031','Hannah','Murray',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a032','Kristian','Nairn',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a033','Mark','Stanley',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a034','Richard','Madden','tw010');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a035','Finn','Jones',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a036','Sibel','Kekilli',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a037','Iwan','Rheon','tw005');
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a038','Michael','McElhatton',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a039','Owen','Teale',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a040','Joe','Dempsie',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a041','Anton','Lesser',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a042','Michiel','Huisman',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a043','Diana','Rigg',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a044','Dean-Charles','Chapman',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a045','Rose','Leslie',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a046','Tom','Wlaschiha',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a047','Brenock','O''Connor',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a048','Ian','Beattie',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a049','Natalia','Tena',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a050','Ellie','Kendrick',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a051','Eugene','Simon',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a052','Dominic','Carter',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a053','Donald','Sumpter',null);
insert into `actor`(`a_id`,`actor_first`,`actor_last`,`fka_twitter_id`) values ('a054','Gemma','Whelan',null);
