Select ep_season, ep_episode, ep_name, ep_key, ep_airdate, ep_director from got_db_loc.episodes
USE got_db_loc;

CREATE TABLE `episodes` (
  `ep_season` int(11) DEFAULT NULL,
  `ep_episode` int(11) DEFAULT NULL,
  `ep_name` text,
  `ep_key` varchar(45) NOT NULL,
  `ep_airdate` text,
  `ep_director` text,
  PRIMARY KEY (`ep_key`),
  UNIQUE KEY `ep_key_UNIQUE` (`ep_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,1,'Winter Is Coming','S01E01','4/17/2011','Tim Van Patten');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,2,'The Kingsroad','S01E02','4/24/2011','Tim Van Patten');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,3,'Lord Snow','S01E03','5/1/2011','Brian Kirk');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,4,'Cripples, Bastards, and Broken Things','S01E04','5/8/2011','Brian Kirk');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,5,'The Wolf and the Lion','S01E05','5/15/2011','Brian Kirk');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,6,'A Golden Crown','S01E06','5/22/2011','Daniel Minahan');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,7,'You Win or You Die','S01E07','5/29/2011','Brian Kirk');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,8,'The Pointy End','S01E08','6/5/2011','Daniel Minahan');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,9,'Baelor','S01E09','6/12/2011','Alan Taylor');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (1,10,'Fire and Blood','S01E10','6/19/2011','Alan Taylor');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,1,'The North Remembers','S02E01','4/1/2012','Alan Taylor');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,2,'The Night Lands','S02E02','4/8/2012','Alan Taylor');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,3,'What Is Dead May Never Die','S02E03','4/15/2012','Alik Sakharov');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,4,'Garden of Bones','S02E04','4/22/2012','David Petrarca');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,5,'The Ghost of Harrenhal','S02E05','4/29/2012','David Petrarca');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,6,'The Old Gods and the New','S02E06','5/6/2012','David Nutter');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,7,'A Man Without Honor','S02E07','5/13/2012','David Nutter');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,8,'The Prince of Winterfell','S02E08','5/20/2012','Alan Taylor');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,9,'Blackwater','S02E09','5/27/2012','Neal Marshal');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (2,10,'Valar Morghulis','S02E10','6/3/2012','Alan Taylor');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,1,'Valar Dohaeris','S03E01','3/31/2013','Daniel Minahan');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,2,'Dark Wings, Dark Words','S03E02','4/7/2013','Daniel Minahan');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,3,'Walk of Punishment','S03E03','4/14/2013','David Benioff');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,4,'And Now His Watch Is Ended','S03E04','4/21/2013','Alex Graves');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,5,'Kissed by Fire','S03E05','4/28/2013','Alex Graves');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,6,'The Climb','S03E06','5/5/2013','Alik Sakharov');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,7,'The Bear and the Maiden Fair','S03E07','5/12/2013','Michelle MacLaren');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,8,'Second Sons','S03E08','5/19/2013','Michelle MacLaren');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,9,'The Rains of Castamere','S03E09','6/2/2013','David Nutter');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (3,10,'Mhysa','S03E10','6/9/2013','David Nutter');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,1,'Two Swords','S04E01','4/6/2014','D.B. Weiss');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,2,'The Lion and the Rose','S04E02','4/13/2014','Alex Graves');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,3,'Breaker of Chains','S04E03','4/20/2014','Alex Graves');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,4,'Oathkeeper','S04E04','4/27/2014','Michelle MacLaren');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,5,'First of His Name','S04E05','5/4/2014','Michelle MacLaren');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,6,'The Laws of Gods and Men','S04E06','5/11/2014','Alik Sakharov');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,7,'Mockingbird','S04E07','5/18/2014','Alik Sakharov');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,8,'The Mountain and the Viper','S04E08','5/25/2014','Alex Graves');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,9,'The Watchers on the Wall','S04E09','6/8/2014','Neil Marshall');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (4,10,'The Children','S04E10','6/15/2014','Alex Graves');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,1,'The Wars to Come','S05E01','4/12/2015','Michael Slovis');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,2,'The House of Black and White','S05E02','4/19/2015','Michael Slovis');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,3,'High Sparrow','S05E03','4/26/2015','Mark Mylod');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,4,'Sons of the Harpy','S05E04','5/4/2015','Mark Mylod');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,5,'Kill the Boy','S05E05','5/10/2015','Jeremy Podeswa');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,6,'Unbowed, Unbent, Unbroken','S05E06','5/17/2015','Jeremy Podeswa');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,7,'The Gift','S05E07','5/24/2015','Miguel Sapochnik');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,8,'Hardhome','S05E08','5/31/2015','Miguel Sapochnik');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,9,'The Dance of Dragons','S05E09','6/7/2015','David Nutter');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (5,10,'Mother''s Mercy','S05E10','6/14/2015','David Nutter');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,1,'The Red Woman','S06E01','4/24/2016','Jeremy Podeswa');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,2,'Home','S06E02','5/1/2016','Jeremy Podeswa');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,3,'Oathbreaker','S06E03','5/8/2016','Daniel Sackheim');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,4,'Book of the Stranger','S06E04','5/15/2016','Daniel Sackheim');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,5,'The Door','S06E05','5/22/2016','Jack Bender');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,6,'Blood of My Blood','S06E06','5/29/2016','Jack Bender');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,7,'The Broken Man','S06E07','6/5/2016','Mark Mylod');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,8,'No One','S06E08','6/12/2016','Mark Mylod');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,9,'Battle of the Bastards','S06E09','6/19/2016','Miguel Sapochnik');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (6,10,'The Winds of Winter','S06E10','6/26/2016','Miguel Sapochnik');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (7,1,'Dragonstone','S07E01','7/16/2017','Jeremy Podeswa');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (7,2,'Stormborn','S07E02','7/23/2017','Mark Mylod');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (7,3,'The Queen''s Justice','S07E03','7/30/2017','Mark Mylod');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (7,4,'The Spoils of War','S07E04','8/6/2017','Matt Shakman');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (7,5,'Eastwatch','S07E05','8/13/2017','Matt Shakman');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (7,6,'Beyond the Wall','S07E06','8/20/2017','Alan Taylor');
insert into `episodes`(`ep_season`,`ep_episode`,`ep_name`,`ep_key`,`ep_airdate`,`ep_director`) values (7,7,'The Dragon and the Wolf','S07E07','8/27/2017','Jeremy Podeswa');
