Select ep_key, ratings from got_db_loc.ratings
USE got_db_loc;

CREATE TABLE `ratings` (
  `ep_key` varchar(45) NOT NULL,
  `ratings` varchar(45) DEFAULT NULL,
  KEY `ep_key_idx` (`ep_key`),
  CONSTRAINT `r.ep_key` FOREIGN KEY (`ep_key`) REFERENCES `episodes` (`ep_key`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


